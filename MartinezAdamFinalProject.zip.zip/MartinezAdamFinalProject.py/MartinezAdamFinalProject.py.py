"""
Author:  Adam Martinez
Date written: 12/09/24
Assignment:   Final Project Application
Short Desc:   File name (MartinezAdamFinalProject) Fitness and Health Tracker GUI
"""

import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk  # For handling images
import sqlite3


# Database Setup
def setup_database():
    """
    Initializes the SQLite database with tables for activities, nutrition, and goals.
    """
    conn = sqlite3.connect('fitness_tracker.db')
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            activity_name TEXT NOT NULL,
            duration INTEGER NOT NULL,
            intensity TEXT NOT NULL,
            date DATE DEFAULT (DATE('now'))
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS nutrition (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            food_item TEXT NOT NULL,
            calories INTEGER NOT NULL,
            carbs INTEGER,
            protein INTEGER,
            fats INTEGER,
            date DATE DEFAULT (DATE('now'))
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            weekly_exercise_goal INTEGER,
            daily_calorie_limit INTEGER
        )
    """)
    conn.commit()
    conn.close()


class FitnessApp(tk.Tk):
    """
    Main application class to initialize the GUI and manage tabs for activities, nutrition, and goals.
    """
    def __init__(self):
        super().__init__()
        self.title("Fitness and Health Tracker")
        self.geometry("800x600")

        # Set a base color scheme
        self.base_bg = "#1e3d59"  # Dark navy
        self.fg_color = "white"
        self.highlight_color = "#aed581"  # Green highlight

        # Use a lighter frame background for contrast
        self.frame_bg = "#2c5f77"

        self.configure(bg=self.base_bg)
        self.init_ui()

    def init_ui(self):
        """
        Initializes the application user interface, including tabs for activities, nutrition, and goals.
        """
        # Configure Notebook (Tabs)
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=self.base_bg, borderwidth=0)
        style.configure("TNotebook.Tab", background=self.base_bg, foreground=self.fg_color, font=('Arial', 12, 'bold'))
        style.map("TNotebook.Tab",
                  background=[("selected", self.highlight_color)],
                  foreground=[("selected", "black")])

        notebook = ttk.Notebook(self)
        notebook.pack(expand=True, fill='both', padx=10, pady=10)

        # Tabs
        self.activity_tab = tk.Frame(notebook, bg=self.frame_bg)
        self.nutrition_tab = tk.Frame(notebook, bg=self.frame_bg)
        self.goal_tab = tk.Frame(notebook, bg=self.frame_bg)

        notebook.add(self.activity_tab, text="Activity Tracking")
        notebook.add(self.nutrition_tab, text="Nutrition Logging")
        notebook.add(self.goal_tab, text="Goal Setting")

        # Load and place images (comment out if image not found)
        self.load_activity_image()
        self.load_nutrition_image()

        # Initialize each tab
        self.init_activity_tab()
        self.init_nutrition_tab()
        self.init_goal_tab()

    def load_activity_image(self):
        """
        Loads and displays the activity image in the Activity Tracking tab.
        """
        try:
            img = Image.open(r"E:\guiImages\fitnessgui1.jpg").resize((200, 150), Image.Resampling.LANCZOS)
            self.activity_image = ImageTk.PhotoImage(img)
            img_label = tk.Label(self.activity_tab, image=self.activity_image, bg=self.frame_bg)
            img_label.grid(row=0, column=2, rowspan=4, padx=20, pady=20, sticky="n")
        except Exception as e:
            print("Error loading activity image:", e)

    def load_nutrition_image(self):
        """
        Loads and displays the nutrition image in the Nutrition Logging tab.
        """
        try:
            img = Image.open(r"E:\guiImages\fitnessgui2.jpg").resize((200, 150), Image.Resampling.LANCZOS)
            self.nutrition_image = ImageTk.PhotoImage(img)
            img_label = tk.Label(self.nutrition_tab, image=self.nutrition_image, bg=self.frame_bg)
            img_label.grid(row=0, column=2, rowspan=5, padx=20, pady=20, sticky="n")
        except Exception as e:
            print("Error loading nutrition image:", e)

    def init_activity_tab(self):
        """
        Initializes the Activity Tracking tab and its functionality.
        """
        tk.Label(self.activity_tab, text="Activity Name:", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=0, column=0, padx=10, pady=5, sticky="e")
        self.activity_name = tk.Entry(self.activity_tab, width=25, bg="white", fg="black")
        self.activity_name.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        tk.Label(self.activity_tab, text="Duration (min):", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=1, column=0, padx=10, pady=5, sticky="e")
        self.activity_duration = tk.Entry(self.activity_tab, width=25, bg="white", fg="black")
        self.activity_duration.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        tk.Label(self.activity_tab, text="Intensity:", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=2, column=0, padx=10, pady=5, sticky="e")
        self.intensity = ttk.Combobox(self.activity_tab, values=["Low", "Medium", "High"], width=23)
        self.intensity.grid(row=2, column=1, padx=10, pady=5, sticky="w")

        log_button = tk.Button(self.activity_tab, text="Log Activity", command=self.log_activity, bg=self.highlight_color, fg="black", font=('Arial', 11, 'bold'))
        log_button.grid(row=3, column=0, columnspan=2, pady=10)

        self.activity_list = tk.Text(self.activity_tab, height=15, width=50, bg="white", fg="black", font=('Arial', 10))
        self.activity_list.grid(row=4, column=0, columnspan=2, padx=10, pady=5)
        self.load_activities()

    def log_activity(self):
        """
        Logs an activity into the database and refreshes the activity list.
        """
        name = self.activity_name.get()
        duration = self.activity_duration.get()
        intensity = self.intensity.get()

        if not name or not duration or not intensity:
            messagebox.showerror("Input Error", "All fields are required!")
            return

        try:
            duration = int(duration)
        except ValueError:
            messagebox.showerror("Input Error", "Duration must be a number!")
            return

        conn = sqlite3.connect('fitness_tracker.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO activities (activity_name, duration, intensity) VALUES (?, ?, ?)",
                       (name, duration, intensity))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Activity logged successfully!")
        self.load_activities()

    def load_activities(self):
        """
        Loads activities from the database and displays them in the activity list.
        """
        conn = sqlite3.connect('fitness_tracker.db')
        cursor = conn.cursor()
        cursor.execute("SELECT activity_name, duration, intensity, date FROM activities")
        records = cursor.fetchall()
        conn.close()

        self.activity_list.delete(1.0, tk.END)
        if records:
            for record in records:
                self.activity_list.insert(tk.END, f"{record[0]} - {record[1]} min - {record[2]} - {record[3]}\n")
        else:
            self.activity_list.insert(tk.END, "No activities logged yet.\n")

    def init_nutrition_tab(self):
        """
        Initializes the Nutrition Logging tab and its functionality.
        """
        tk.Label(self.nutrition_tab, text="Food Item:", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=0, column=0, padx=10, pady=5, sticky="e")
        self.food_item = tk.Entry(self.nutrition_tab, width=25, bg="white", fg="black")
        self.food_item.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        tk.Label(self.nutrition_tab, text="Calories:", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=1, column=0, padx=10, pady=5, sticky="e")
        self.calories = tk.Entry(self.nutrition_tab, width=25, bg="white", fg="black")
        self.calories.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        tk.Label(self.nutrition_tab, text="Carbs (g):", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=2, column=0, padx=10, pady=5, sticky="e")
        self.carbs = tk.Entry(self.nutrition_tab, width=25, bg="white", fg="black")
        self.carbs.grid(row=2, column=1, padx=10, pady=5, sticky="w")

        tk.Label(self.nutrition_tab, text="Protein (g):", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=3, column=0, padx=10, pady=5, sticky="e")
        self.protein = tk.Entry(self.nutrition_tab, width=25, bg="white", fg="black")
        self.protein.grid(row=3, column=1, padx=10, pady=5, sticky="w")

        tk.Label(self.nutrition_tab, text="Fats (g):", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=4, column=0, padx=10, pady=5, sticky="e")
        self.fats = tk.Entry(self.nutrition_tab, width=25, bg="white", fg="black")
        self.fats.grid(row=4, column=1, padx=10, pady=5, sticky="w")

        log_button = tk.Button(self.nutrition_tab, text="Log Nutrition", command=self.log_nutrition, bg=self.highlight_color, fg="black", font=('Arial', 11, 'bold'))
        log_button.grid(row=5, column=0, columnspan=2, pady=10)

        self.nutrition_list = tk.Text(self.nutrition_tab, height=15, width=50, bg="white", fg="black", font=('Arial', 10))
        self.nutrition_list.grid(row=6, column=0, columnspan=2, padx=10, pady=5)
        self.load_nutrition()

    def log_nutrition(self):
        """
        Logs a nutrition entry into the database and refreshes the nutrition list.
        """
        food_item = self.food_item.get()
        calories = self.calories.get()
        carbs = self.carbs.get()
        protein = self.protein.get()
        fats = self.fats.get()

        if not food_item or not calories:
            messagebox.showerror("Input Error", "Food Item and Calories are required!")
            return

        try:
            calories = int(calories)
            carbs = int(carbs) if carbs else 0
            protein = int(protein) if protein else 0
            fats = int(fats) if fats else 0
        except ValueError:
            messagebox.showerror("Input Error", "Calories, Carbs, Protein, and Fats must be numbers!")
            return

        conn = sqlite3.connect('fitness_tracker.db')
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO nutrition (food_item, calories, carbs, protein, fats) 
            VALUES (?, ?, ?, ?, ?)
        """, (food_item, calories, carbs, protein, fats))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Nutrition logged successfully!")
        self.load_nutrition()

    def load_nutrition(self):
        """
        Loads nutrition entries from the database and displays them in the nutrition list.
        """
        conn = sqlite3.connect('fitness_tracker.db')
        cursor = conn.cursor()
        cursor.execute("SELECT food_item, calories, carbs, protein, fats, date FROM nutrition")
        records = cursor.fetchall()
        conn.close()

        self.nutrition_list.delete(1.0, tk.END)
        if records:
            for record in records:
                self.nutrition_list.insert(tk.END, f"{record[0]} - {record[1]} cal - {record[2]}g carbs - {record[3]}g protein - {record[4]}g fats - {record[5]}\n")
        else:
            self.nutrition_list.insert(tk.END, "No nutrition records found.\n")

    def init_goal_tab(self):
        """
        Initializes the Goal Setting tab and its functionality.
        """
        tk.Label(self.goal_tab, text="Weekly Exercise Goal (hours):", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=0, column=0, padx=10, pady=5, sticky="e")
        self.exercise_goal = tk.Entry(self.goal_tab, width=25, bg="white", fg="black")
        self.exercise_goal.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        tk.Label(self.goal_tab, text="Daily Calorie Limit:", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 11)).grid(row=1, column=0, padx=10, pady=5, sticky="e")
        self.calorie_limit = tk.Entry(self.goal_tab, width=25, bg="white", fg="black")
        self.calorie_limit.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        goal_button = tk.Button(self.goal_tab, text="Set Goals", command=self.set_goals, bg=self.highlight_color, fg="black", font=('Arial', 11, 'bold'))
        goal_button.grid(row=2, column=0, columnspan=2, pady=10)

        self.goal_status = tk.Label(self.goal_tab, text="", bg=self.frame_bg, fg=self.fg_color, font=('Arial', 12, 'bold'))
        self.goal_status.grid(row=3, column=0, columnspan=2, pady=10)

    def set_goals(self):
        """
        Sets fitness goals into the database and updates the goal display.
        """
        exercise_goal = self.exercise_goal.get()
        calorie_limit = self.calorie_limit.get()

        if not exercise_goal or not calorie_limit:
            messagebox.showerror("Input Error", "All fields are required!")
            return

        try:
            exercise_goal = int(exercise_goal)
            calorie_limit = int(calorie_limit)
        except ValueError:
            messagebox.showerror("Input Error", "Goals must be numbers!")
            return

        conn = sqlite3.connect('fitness_tracker.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM goals")
        cursor.execute("INSERT INTO goals (weekly_exercise_goal, daily_calorie_limit) VALUES (?, ?)",
                       (exercise_goal, calorie_limit))
        conn.commit()
        conn.close()

        self.goal_status.config(text=f"Weekly Goal: {exercise_goal} hrs | Daily Limit: {calorie_limit} cal")
        messagebox.showinfo("Success", "Goals set successfully!")


if __name__ == "__main__":
    setup_database()
    app = FitnessApp()
    app.mainloop()
